### 青龙拉库命令

```shell
ql repo https://github.com/pingxingsheng/elm.git "^ele" "" "USER|common|ql|sendNotify1"
```

定时的话，每天1点拉一次 `0 1 * * *`

飞机频道：[https://t.me/tigerorrose](https://t.me/tigerorrose)
